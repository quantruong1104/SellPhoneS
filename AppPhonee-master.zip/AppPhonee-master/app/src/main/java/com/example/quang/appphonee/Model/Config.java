package com.example.quang.appphonee.Model;

/**
 * Created by quang on 5/9/19.
 */

public class Config {
    public static final String PAYPAL_CLIENT_ID = "AYYy3JTt9HvwR_tfZUDVv-wg5W1BiZtgMsAgGjj0F5T5nzgtrr4_B_vNM6tJ5QgsiZWz5usA1WPCRq-w";
}
