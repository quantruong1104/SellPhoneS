package com.example.quang.appphonee;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by quang on 5/24/19.
 */

public class ChiTietKhuyenMai extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chitietkhuyenmai);


    }
}
